"""
    trakt.py --- Jen Plugin for accessing trakt data
    Copyright (C) 2017, Midraal

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.


    Usage Examples:
    <dir>
      <title>Trending Movies</title>
      <trakt>https://api.trakt.tv/movies/trending</trakt>
    </dir>

    <dir>
      <title>Popular Movies</title>
      <trakt>https://api.trakt.tv/movies/popular</trakt>
    </dir>

    <dir>
      <title>Movie Watchlist</title>
      <trakt>https://api.trakt.tv/sync/watchlist/movies</trakt>
    </dir>

    <dir>
      <title>Movie Collection</title>
      <trakt>https://api.trakt.tv/sync/collection/movies</trakt>
    </dir>

    <dir>
      <title>Trending Shows</title>
      <trakt>https://api.trakt.tv/shows/trending</trakt>
    </dir>

    <dir>
      <title>Popular Shows</title>
      <trakt>https://api.trakt.tv/shows/popular</trakt>
    </dir>

    <dir>
      <title>TV Watchlist</title>
      <trakt>https://api.trakt.tv/sync/watchlist/shows</trakt>
    </dir>

    <dir>
      <title>TV Collection</title>
      <trakt>https://api.trakt.tv/sync/collection/shows</trakt>
    </dir>

    <dir>
      <title>My lists</title>
      <trakt>https://api.trakt.tv/users/me/lists/</trakt>
    </dir>

    <dir>
      <title>My Liked Lists</title>
      <trakt>https://api.trakt.tv/users/likes/lists</trakt>
    </dir>

    <dir>
      <title>Reddit Top 250 (2017 Edition)</title>
      <trakt>https://api.trakt.tv/users/philrivers/lists/reddit-top-250-2017-edition/items</trakt>
    </dir>

    <dir>
      <title>Bryan Cranston Movies Trakt</title>
      <trakt>https://api.trakt.tv/people/bryan-cranston/movies</trakt>
    </dir>

    <dir>
      <title>Bryan Cranston shows Trakt</title>
      <trakt>https://api.trakt.tv/people/bryan-cranston/shows</trakt>
    </dir>
"""

import __builtin__
import pickle
import time

import requests

import koding
import resources.lib.external.tmdbsimple as tmdbsimple
import xbmc
import xbmcaddon
import xbmcgui
from ..plugin import Plugin
from koding import route
from resources.lib.util.context import get_context_items
from resources.lib.util.xml import JenItem, JenList, display_list
from unidecode import unidecode


CACHE_TIME = 3600  # change to wanted cache time in seconds
CACHE_TMDB_TIME = 3600 * 24 * 30
SKIP_TMDB_INFO = True

TRAKT_API_KEY = __builtin__.trakt_client_id
TRAKT_SECRET = __builtin__.trakt_client_secret
addon_fanart = xbmcaddon.Addon().getAddonInfo('fanart')
addon_icon = xbmcaddon.Addon().getAddonInfo('icon')


class Trakt(Plugin):
    name = "trakt"

    def process_item(self, item_xml):
        if "<trakt>" in item_xml:
            item = JenItem(item_xml)
            result_item = {
                'label': item["title"],
                'icon': item.get("thumbnail", addon_icon),
                'fanart': item.get("fanart", addon_fanart),
                'mode': "trakt",
                'url': item.get("trakt", ""),
                'folder': True,
                'imdb': "0",
                'content': "files",
                'season': "0",
                'episode': "0",
                'info': {},
                'year': "0",
                'context': get_context_items(item),
                "summary": item.get("summary", None)
            }
            result_item["properties"] = {'fanart_image': result_item["fanart"]}
            result_item['fanart_small'] = result_item["fanart"]
            return result_item
        elif "trakt_tv_show(" in item_xml:
            item = JenItem(item_xml)
            url = item.get("link", ")").replace("trakt_tv_show(", "")[:-1]
            result_item = {
                'label': item["title"],
                'icon': item.get("thumbnail", addon_icon),
                'fanart': item.get("fanart", addon_fanart),
                'mode': "trakt_tv_show",
                'url': "trakt_id" + url,
                'folder': True,
                'imdb': item.get("imdb", ""),
                'content': "tvshows",
                'season': "0",
                'episode': "0",
                'info': {},
                'year': item.get("year", ""),
                'context': get_context_items(item),
                "summary": item.get("summary", None)
            }
            result_item["properties"] = {'fanart_image': result_item["fanart"]}
            result_item['fanart_small'] = result_item["fanart"]
            return result_item
        elif "trakt_season(" in item_xml:
            item = JenItem(item_xml)
            url = item.get("link", ")").replace("trakt_season(", "")[:-1]
            season = url.split(",")[1]
            result_item = {
                'label': item["title"],
                'icon': item.get("thumbnail", addon_icon),
                'fanart': item.get("fanart", addon_fanart),
                'mode': "trakt_season",
                'url': "trakt_id" + url,
                'folder': True,
                'imdb': item.get("imdb", ""),
                'content': "tvshows",
                'season': str(season),
                'episode': "0",
                'info': {},
                'year': item.get("year", ""),
                'context': {},
                "summary": item.get("summary", None)
            }
            result_item["properties"] = {'fanart_image': result_item["fanart"]}
            result_item['fanart_small'] = result_item["fanart"]
            return result_item
        elif "trakt_list(" in item_xml:
            item = JenItem(item_xml)
            url = item.get("link", ")").replace("trakt_list(", "")[:-1]
            user_id, list_id = url.split(",")
            list_url = "https://api.trakt.tv/users/%s/lists/%s/items/" % (user_id, list_id)
            result_item = {
                'label': item["title"],
                'icon': item.get("thumbnail", addon_icon),
                'fanart': item.get("fanart", addon_fanart),
                'mode': "trakt",
                'url': list_url,
                'folder': True,
                'imdb': item.get("imdb", ""),
                'content': "files",
                'season': "0",
                'episode': "0",
                'info': {},
                'year': item.get("year", ""),
                'context': {},
                "summary": item.get("summary", None)
            }
            result_item["properties"] = {'fanart_image': result_item["fanart"]}
            result_item['fanart_small'] = result_item["fanart"]
            return result_item

        return False


@route(mode='trakt', args=["url"])
def trakt(url):
    headers = {
        'Content-Type': 'application/json',
        'trakt-api-version': '2',
        'trakt-api-key': TRAKT_API_KEY
    }
    if "sync" in url or "user" in url:
        if "list" not in url or "/me/" in url or "like" in url or "sync" in url:
            auth = authenticate()
            if auth:
                headers['Authorization'] = 'Bearer ' + auth
            else:
                return ""
    response = fetch_from_db(url)
    if not response:
        response = requests.get(url, headers=headers).json()
        save_to_db(response, url)
    xml = ""
    if type(response) == dict:
        if "people" in url:
            for job in response:
                for item in response[job]:
                    if "movie" in item:
                        xml += get_movie_xml(item["movie"])
                    elif "show" in item:
                        xml += get_show_xml(item["show"])

    elif type(response) == list:
        for item in response:
            if "lists" in url:
                if "items" not in url and "likes" not in url:
                    user_id = url.split("/")[4]
                    xml += get_lists_xml(item, user_id)
                if "likes/lists" in url:
                    xml += get_likes_xml(item)
            if "movie" in item:
                xml += get_movie_xml(item["movie"])
            elif "show" in item:
                xml += get_show_xml(item["show"])
            else:  # one of the annoying types
                if "movies" in url:
                    xml += get_movie_xml(item)
                elif "shows" in url and "season" not in url:
                    xml += get_show_xml(item)
    jenlist = JenList(xml)
    display_list(jenlist.get_list(), jenlist.get_content_type())


@route(mode='trakt_tv_show', args=["url"])
def trakt_tv_show(trakt_id):
    trakt_id, year, tvtitle, tmdb = trakt_id.replace("trakt_id", "").split(",")
    url = "https://api.trakt.tv/shows/%s/seasons" % trakt_id
    headers = {
        'Content-Type': 'application/json',
        'trakt-api-version': '2',
        'trakt-api-key': TRAKT_API_KEY
    }
    response = fetch_from_db(url)
    if not response:
        response = requests.get(url, headers=headers).json()
        save_to_db(response, url)
    xml = ""
    if type(response) == list:
        for item in response:
            xml += get_season_xml(item, trakt_id, year, tvtitle, tmdb)
        jenlist = JenList(xml)
        display_list(jenlist.get_list(), jenlist.get_content_type())


@route(mode='trakt_season', args=["url"])
def trakt_season(slug):
    trakt_id, season, year, tvtitle, tmdb = slug.replace("trakt_id", "").split(",")
    url = "https://api.trakt.tv/shows/%s/seasons/%s?extended=full"
    url = url % (trakt_id, season)
    headers = {
        'Content-Type': 'application/json',
        'trakt-api-version': '2',
        'trakt-api-key': TRAKT_API_KEY
    }
    response = fetch_from_db(url)
    if not response:
        response = requests.get(url, headers=headers).json()
        save_to_db(response)
    xml = ""
    if type(response) == list:
        for item in response:
            xml += get_episode_xml(item, trakt_id, year, tvtitle, tmdb)
        jenlist = JenList(xml)
        display_list(jenlist.get_list(), jenlist.get_content_type())


def get_movie_xml(item):
    if "movie" in item:
        item = item["movie"]

    title = remove_non_ascii(item["title"])
    year = item["year"]
    imdb = item["ids"]["imdb"]
    tmdb = item["ids"]["tmdb"]
    info = fetch_from_db("tmdb/%s/movie" % (tmdb))
    if not info:
        if not SKIP_TMDB_INFO:
            info = tmdbsimple.Movies(tmdb).info()
            save_to_db(info, "tmdb/%s/movie" % (tmdb))
        else:
            info = {}
    if info.get("poster_path"):
        thumbnail = "https://image.tmdb.org/t/p/w342/" + info["poster_path"]
    else:
        thumbnail = ""
    if info.get("backdrop_path", ""):
        fanart = "https://image.tmdb.org/t/p/w342/" + info["backdrop_path"]
    else:
        fanart = ""
    xml = "<item>" \
          "<title>%s</title>" \
          "<meta>" \
          "<content>movie</content>" \
          "<imdb>%s</imdb>" \
          "<title>%s</title>" \
          "<year>%s</year>" \
          "</meta>" \
          "<link>" \
          "<sublink>search</sublink>" \
          "<sublink>searchsd</sublink>" \
          "</link>" \
          "<thumbnail>%s</thumbnail>" \
          "<fanart>%s</fanart>" \
          "</item>" % (title, imdb, title, year, thumbnail, fanart)
    return xml


def get_show_xml(item):
    if "show" in item:
        item = item["show"]
    title = remove_non_ascii(item["title"])
    year = item["year"]
    imdb = item["ids"]["imdb"]
    trakt_id = item["ids"]["trakt"]
    tmdb = item["ids"]["tmdb"]
    info = fetch_from_db("tmdb/%s/show" % (tmdb))
    if not info:
        if not SKIP_TMDB_INFO:
            info = tmdbsimple.TV(tmdb).info()
            save_to_db(info, "tmdb/%s" % (tmdb))
        else:
            info = {}
    if info.get("poster_path", ""):
        thumbnail = "https://image.tmdb.org/t/p/w342/" + info["poster_path"]
    else:
        thumbnail = ""
    if info.get("backdrop_path", ""):
        fanart = "https://image.tmdb.org/t/p/w342/" + info["backdrop_path"]
    else:
        fanart = ""
    xml = "<dir>"\
          "<title>%s</title>"\
          "<meta>"\
          "<content>tvshow</content>"\
          "<imdb>%s</imdb>"\
          "<tvshowtitle>%s</tvshowtitle>"\
          "<year>%s</year>"\
          "</meta>"\
          "<link>trakt_tv_show(%s, %s, %s, %s)</link>"\
          "<thumbnail>%s</thumbnail>" \
          "<fanart>%s</fanart>" \
          "</dir>" % (title, imdb, title, year, trakt_id, year, title, tmdb,
                      thumbnail, fanart)
    return xml


def get_season_xml(item, trakt_id, year, tvtitle, tmdb):
    season = item["number"]
    if season == 0:
        return ""
    info = fetch_from_db("tmdb/%s/%s" % (tmdb, season))
    if not info:
        if not SKIP_TMDB_INFO:
            info = tmdbsimple.TV_Seasons(tmdb, season).info()
            save_to_db(info, "tmdb/%s/%s" % (tmdb, season))
        else:
            info = {}
    if info.get("poster_path", ""):
        thumbnail = "https://image.tmdb.org/t/p/w342/" + info["poster_path"]
    else:
        thumbnail = ""
    if info.get("backdrop_path", ""):
        fanart = "https://image.tmdb.org/t/p/w342/" + info["backdrop_path"]
    else:
        fanart = ""
    xml = "<dir>"\
          "<title>Season %s</title>"\
          "<meta>"\
          "<content>season</content>"\
          "<season>%s</season>"\
          "</meta>"\
          "<link>trakt_season(%s,%s, %s, %s, %s)</link>"\
          "<thumbnail>%s</thumbnail>" \
          "<fanart>%s</fanart>" \
          "</dir>" % (season, season, trakt_id, season, year, tvtitle, tmdb,
                      thumbnail, fanart)
    return xml


def get_episode_xml(item, trakt_id, year, tvtitle, tmdb):
    title = item["title"]
    imdb = item["ids"]["imdb"]
    if not imdb:
        return ""
    premiered = item["first_aired"].split("T")[0]
    season = item["season"]
    episode = item["number"]
    info = fetch_from_db("tmdb/%s/%s/%s" % (tmdb, season, episode))
    if not info:
        if not SKIP_TMDB_INFO:
            info = tmdbsimple.TV_Episodes(tmdb, season, episode).info()
            save_to_db(info, "tmdb/%s/%s/%s" % (tmdb, season, episode))
        else:
            info = {}
    if info["still_path"]:
        thumbnail = "https://image.tmdb.org/t/p/w342/" + info["still_path"]
    else:
        thumbnail = ""
    if info.get("backdrop_path", ""):
        fanart = "https://image.tmdb.org/t/p/w342/" + info["backdrop_path"]
    else:
        fanart = ""
    xml = "<item>"\
          "<title>%s</title>"\
          "<meta>"\
          "<content>episode</content>"\
          "<imdb>%s</imdb>"\
          "<tvshowtitle>%s</tvshowtitle>"\
          "<year>%s</year>"\
          "<title>%s</title>"\
          "<premiered>%s</premiered>"\
          "<season>%s</season>"\
          "<episode>%s</episode>"\
          "</meta>"\
          "<link>"\
          "<sublink>search</sublink>"\
          "<sublink>searchsd</sublink>"\
          "</link>"\
          "<thumbnail>%s</thumbnail>" \
          "<fanart>%s</fanart>" \
          "</item>" % (title, imdb, tvtitle, year, title,
                       premiered, season, episode,
                       thumbnail, fanart)
    return xml


def get_lists_xml(item, user_id):
    title = item["name"]
    trakt_id = item["ids"]["trakt"]
    summary = item["description"]
    xml = "<dir>"\
          "<title>%s</title>"\
          "<link>trakt_list(%s, %s)</link>"\
          "<summary>%s</summary"\
          "</dir>" % (title, user_id, trakt_id, summary)
    return xml


def get_likes_xml(item):
    title = remove_non_ascii(item["list"]["name"])
    trakt_id = item["list"]["ids"]["trakt"]
    user_id = item["list"]["user"]["ids"]["slug"]
    summary = item["list"]["description"]
    xml = "<dir>"\
          "<title>%s</title>"\
          "<link>trakt_list(%s, %s)</link>"\
          "<summary>%s</summary"\
          "</dir>" % (title, user_id, trakt_id, summary)
    return xml


def authenticate():
    addon = xbmcaddon.Addon()
    access_token = addon.getSetting("TRAKT_ACCESS_TOKEN")
    if access_token:
        return access_token
    values = {
        "client_id": TRAKT_API_KEY
    }

    device_codes = requests.post('https://api.trakt.tv/oauth/device/code',
                                 data=values).json()
    data = {
        "code": device_codes["device_code"],
        "client_id": TRAKT_API_KEY,
        "client_secret": TRAKT_SECRET
    }

    start = time.time()
    expires_in = device_codes["expires_in"]
    progress_dialog = xbmcgui.DialogProgress()
    progress_dialog.create(
        "Authenticate Trakt",
        "Please go to https://trakt.tv/activate and enter the code",
        str(device_codes["user_code"])
    )
    try:
        time_passed = 0
        while not xbmc.abortRequested and not progress_dialog.iscanceled() and time_passed < expires_in:
            try:
                response = requests.post(
                    'https://api.trakt.tv/oauth/device/token',
                    data=data).json()
            except Exception, e:
                progress = int(100 * time_passed / expires_in)
                progress_dialog.update(progress)
                xbmc.sleep(max(device_codes["interval"], 1)*1000)
            else:
                response = response
                expires_at = time.time() + 60*60*24*30
                addon.setSetting("TRAKT_EXPIRES_AT", str(expires_at))
                addon.setSetting("TRAKT_ACCESS_TOKEN",
                                 response["access_token"])
                addon.setSetting("TRAKT_REFRESH_TOKEN",
                                 response["refresh_token"])
                return response["access_token"]
            time_passed = time.time() - start
    finally:
        progress_dialog.close()
        del progress_dialog
    return None


def remove_non_ascii(text):
    return unidecode(text)


def save_to_db(item, url):
    koding.reset_db()
    koding.Remove_From_Table(
        "trakt_plugin",
        {
            "url": url
        })

    koding.Add_To_Table("trakt_plugin",
                        {
                            "url": url,
                            "item": pickle.dumps(item),
                            "created": time.time()
                        })


def fetch_from_db(url):
    koding.reset_db()
    trakt_plugin_spec = {
        "columns": {
            "url": "TEXT",
            "item": "TEXT",
            "created": "TEXT"
        },
        "constraints": {
            "unique": "url"
        }
    }
    koding.Create_Table("trakt_plugin", trakt_plugin_spec)
    match = koding.Get_From_Table(
        "trakt_plugin", {"url": url})
    if match:
        match = match[0]
        if not match["item"]:
            return None
        created_time = match["created"]
        if "tmdb" in url:
            if created_time and float(created_time) <= time.time() + CACHE_TMDB_TIME:
                match_item = match["item"].replace("'", "\"")
                try:
                    match_item = match_item.encode('ascii', 'ignore')
                except:
                    match_item = match_item.decode('utf-8').encode('ascii', 'ignore')
                return pickle.loads(match_item)
        if created_time and float(created_time) <= time.time() + CACHE_TIME:
            match_item = match["item"].replace("'", "\"")
            try:
                match_item = match_item.encode('ascii', 'ignore')
            except:
                match_item = match_item.decode('utf-8').encode('ascii', 'ignore')
            return pickle.loads(match_item)
        else:
            return []
    else:
        return []
