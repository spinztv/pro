skin.xonfluence: Is the original skin xonfluspinz was created from.

For More Info on Xonfluence See:
http://forum.kodi.tv/showthread.php?tid=238630
     



